package extractor;

public class Answer {
	public String UserID;
	public String Content;
	public String AnswerTime;
	public String SupportCount;
	public String OpposeCount;
	public String CommentCount;
}
