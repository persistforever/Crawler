package extractor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import us.codecraft.webmagic.selector.Html;

public class WebInfoExtractor {
	public static String SafeGet(List list,int index){
		if(list.size()<=index)return "";
		return list.get(index).toString().trim();
	}
	
	public static void main(String[] args) throws Exception{
		System.out.println(args[0]+'\t'+args[1]);
		BufferedReader reader = new BufferedReader(new FileReader(args[0]));
		FileWriter writer = new FileWriter(new File(args[1]));
		String line = null;
		while(true){
			line = reader.readLine();
			if(line==null)return;
			if(line.equals("!!"))break;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		while(true){
			if(line.equals("!!")){
				StringBuffer buffer = new StringBuffer();
				while(true){
					line = reader.readLine();
					if(line!=null&&!line.equals("!!")){
						buffer.append(line);
					}
					if(line==null||line.equals("!!")){
						break;
					}
				}
				String strHtml = buffer.toString();
				Html html = new Html(strHtml);
				String questionID = SafeGet(html.xpath("//div/@data-urltoken").all(),0);
				String question = SafeGet(html.xpath("//*[@id='zh-question-title']/h2/text()").all(),0);
				String description = SafeGet(html.xpath("//*[@id='zh-question-detail']/div/text()").all(),0);
				String attentions = SafeGet(html.xpath("//*[@id='zh-question-side-header-wrap']/text()").all(),0);
				attentions = attentions.replaceAll("[^0-9]+","").replaceAll("[\\r\\n\\t ]+","");
				List<String> answerStrList = html.xpath("//*[@id='zh-question-answer-wrap']/div").all();
				List<Answer> answerList = new ArrayList<Answer>();
				for(String strAnsHtml:answerStrList){
					Html ansHtml = new Html(strAnsHtml);
					Answer answer = new Answer();
					//�ش����ǳ�
					answer.UserID = SafeGet(ansHtml.xpath("//h3[@class='zm-item-answer-author-wrap']/a[2]/text()").all(),0);
					//�ش�����
					answer.Content = SafeGet(ansHtml.xpath("//div[@class='zm-item-rich-text']/div/text()").all(),0);
					//֧������
					answer.SupportCount = SafeGet(ansHtml.xpath("//button[@class='up']/span[@class='count']/text()").all(),0);
					//��������
					answer.OpposeCount = SafeGet(ansHtml.xpath("//button[@class='down']/span[@class='count']/text()").all(),0);
					if("".equals(answer.OpposeCount))answer.OpposeCount="0";
					//�ش�ʱ��
					answer.AnswerTime = SafeGet(ansHtml.xpath("//span[@class='answer-date-link-wrap']/a/text()").all(),0);
					answer.AnswerTime = answer.AnswerTime.replace("������ ", "").replace("�༭�� ", "");
					try{
						answer.AnswerTime = "" + sdf.parse(answer.AnswerTime).getTime();
					}catch(ParseException e){
						answer.AnswerTime = "" + new Date().getTime();
					}
					//*[@id="zh-question-answer-wrap"]/div[2]/div[4]/div/a[1]/text()
					answer.CommentCount = SafeGet(ansHtml.xpath("//div[@class='zm-meta-panel']/a[1]/text()").all(),0);
					answer.CommentCount = answer.CommentCount.replaceAll("[^0-9]+","");
					if("".equals(answer.CommentCount))answer.CommentCount="0";
					answerList.add(answer);
				}
				for(Answer answer:answerList){
					StringBuffer outBuffer = new StringBuffer();
					outBuffer.append("!!\n");
					outBuffer.append("KNOWLEDGE\n");
					outBuffer.append("QT"+question+"\n");
					outBuffer.append("UL"+"http://www.zhihu.com/question/"+questionID+"\n");
					outBuffer.append("DS"+description+"\n");
					outBuffer.append("AC"+answerList.size()+"\n");
					outBuffer.append("AT"+attentions+"\n");
					outBuffer.append("AS"+answer.Content+"\n");
					outBuffer.append("AD"+answer.UserID+"\n");
					outBuffer.append("SU"+answer.SupportCount+"\n");
					outBuffer.append("OU"+answer.OpposeCount+"\n");
					outBuffer.append("AM"+answer.AnswerTime+"\n");
					outBuffer.append("CC"+answer.CommentCount+"\n");
					outBuffer.append("KNOWLEDGE\n\n");
					
					writer.write(outBuffer.toString());
				}
				if(line==null)break;
			}
		}
		reader.close();
		writer.close();
	}
}
